package sep.tippspiel.liga;

public class LigaController {
}
