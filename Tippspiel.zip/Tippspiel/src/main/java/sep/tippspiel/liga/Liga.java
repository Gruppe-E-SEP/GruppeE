package sep.tippspiel.liga;

import sep.tippspiel.spielplan.Spielplan;

import java.awt.*;

public class Liga {

    private String name;
    private Spielplan spielplan;
    private Image ligaImage;
}
