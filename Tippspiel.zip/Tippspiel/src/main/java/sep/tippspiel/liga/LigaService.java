package sep.tippspiel.liga;

public class LigaService {
}
