package sep.tippspiel.liga;

public interface LigaRepository {
}
