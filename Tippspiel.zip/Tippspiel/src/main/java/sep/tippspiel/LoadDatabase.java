package sep.tippspiel;

import org.springframework.context.annotation.Configuration;

@Configuration
public class LoadDatabase {
}
