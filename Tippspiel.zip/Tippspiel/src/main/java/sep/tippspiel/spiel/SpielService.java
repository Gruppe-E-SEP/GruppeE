package sep.tippspiel.spiel;

public class SpielService {
}
