package sep.tippspiel.spiel;

public interface SpielRepository {
}
