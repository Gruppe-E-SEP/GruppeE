package sep.tippspiel.spiel;

public class SpielNotFoundException {
}
