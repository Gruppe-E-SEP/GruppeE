package sep.tippspiel.spiel;

import sep.tippspiel.mannschaft.Mannschaft;

public class Spiel {

    private Mannschaft heimmannschaft;
    private Mannschaft auswärtsmannschaft;
}
