package sep.tippspiel.user;

public class UserService {
}
