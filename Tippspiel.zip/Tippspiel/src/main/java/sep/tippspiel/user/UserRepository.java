package sep.tippspiel.user;

public interface UserRepository {
}
