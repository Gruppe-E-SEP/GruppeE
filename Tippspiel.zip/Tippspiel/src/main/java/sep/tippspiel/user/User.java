package sep.tippspiel.user;

import sep.tippspiel.generaluser.GeneralUser;

import java.awt.*;
import java.util.Date;

public class User extends GeneralUser {

    private String vorname;
    private String nachname;
    private String email;
    private Date date;
    private String passwort;
    private Image image;


}