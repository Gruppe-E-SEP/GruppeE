package sep.tippspiel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TippspielApplication {

    public static void main(String[] args) {
        SpringApplication.run(TippspielApplication.class, args);
    }

}
