package sep.tippspiel.systemdatum;

import java.util.Date;

public class SystemDatum {

    private Date date;
}
