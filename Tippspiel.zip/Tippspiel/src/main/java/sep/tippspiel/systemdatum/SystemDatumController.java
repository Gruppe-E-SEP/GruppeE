package sep.tippspiel.systemdatum;

public class SystemDatumController {
}
