package sep.tippspiel.systemdatum;

public interface SystemDatumRepository {
}
