package sep.tippspiel.systemdatum;

public class SystemDatumService {
}
