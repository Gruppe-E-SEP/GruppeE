package sep.tippspiel.spielplan;

public class SpielplanController {
}
