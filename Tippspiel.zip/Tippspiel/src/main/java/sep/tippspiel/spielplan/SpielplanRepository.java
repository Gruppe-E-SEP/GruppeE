package sep.tippspiel.spielplan;

public interface SpielplanRepository {
}
