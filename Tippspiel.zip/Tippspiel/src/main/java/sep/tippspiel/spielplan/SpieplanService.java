package sep.tippspiel.spielplan;

public class SpieplanService {
}
