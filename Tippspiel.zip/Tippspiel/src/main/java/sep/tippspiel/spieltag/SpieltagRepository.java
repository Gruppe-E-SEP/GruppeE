package sep.tippspiel.spieltag;

public interface SpieltagRepository {
}
