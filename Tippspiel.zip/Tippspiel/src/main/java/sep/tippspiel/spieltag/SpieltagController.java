package sep.tippspiel.spieltag;

public class SpieltagController {
}
