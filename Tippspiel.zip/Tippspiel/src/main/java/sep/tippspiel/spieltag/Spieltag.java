package sep.tippspiel.spieltag;

import sep.tippspiel.spiel.Spiel;

import java.util.List;

public class Spieltag {

    private List<Spiel> spielList;
}
