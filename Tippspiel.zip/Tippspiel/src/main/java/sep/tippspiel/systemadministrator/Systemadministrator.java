package sep.tippspiel.systemadministrator;

public class Systemadministrator {

    private String vorname;
    private String nachname;
    private String email;
    private String passwort;

}
