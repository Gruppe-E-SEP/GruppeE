package sep.tippspiel.systemadministrator;

public interface SystemadministratorRepository {
}
