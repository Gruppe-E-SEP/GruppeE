package sep.tippspiel.systemadministrator;

public class SystemadministratorController {
}
