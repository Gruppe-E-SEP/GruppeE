package sep.tippspiel.systemadministrator;

public class SystemadministratorService {
}
