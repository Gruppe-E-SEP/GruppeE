package sep.tippspiel.mannschaft;

public interface MannschaftRepository {
}
