package sep.tippspiel.mannschaft;

public class MannschaftService {
}
