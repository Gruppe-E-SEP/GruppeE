package sep.tippspiel.mannschaft;

public class Mannschaft {

    private String name;
}
